#ifndef TRAFFIC_H
#define TRAFFIC_H

void trafficmeter(char iface[], unsigned int sampletime);
void livetrafficmeter(char iface[], int mode);

#endif
