#ifndef VNSTATD_H
#define VNSTATD_H

void showhelp(void);

#endif
